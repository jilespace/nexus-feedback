# Nexus Feedback

面向开发者的用户反馈管理 SaaS 平台。帮助产品团队收集、组织、优先排序用户反馈，通过公开看板和更新日志保持用户参与感。

## 核心功能

- **多租户团队系统** — 组织 → 项目 → 成员（Owner/Admin/Member 三角色）
- **反馈收集** — Widget 嵌入、公开提交页、API 直接调用
- **用户投票** — 邮箱标识，按热度排序，无需注册
- **公开反馈看板** — 用户可浏览、投票、评论反馈
- **路线图** — Kanban 视图（计划中 / 进行中 / 已完成）
- **更新日志（Changelog）** — 发布产品更新，关联已解决反馈
- **标签系统** — 自由标签分类 + 批量操作
- **内部备注** — 仅管理员可见的反馈备注
- **反馈合并** — 合并重复反馈，投票自动合并
- **自定义状态** — 每个项目可配置独立的状态工作流
- **Webhook 集成** — 反馈创建/状态变更时推送通知
- **邮件通知** — 状态变更通知投票者、密码重置
- **数据导出** — CSV 格式导出反馈列表
- **附件上传** — 支持图片和 PDF，拖拽上传，支持本地/S3/七牛云存储
- **暗色模式** — 管理后台支持明暗主题切换
- **国际化** — 中英文切换
- **API 限流** — 防止接口滥用
- **键盘快捷键** — K 搜索、J/K 导航、? 帮助

## 技术栈

| 层 | 技术 |
|---|---|
| 后端 | Node.js + Express + TypeScript + Prisma |
| 数据库 | PostgreSQL |
| 前端 | React 18 + TypeScript + Tailwind CSS + Vite |
| 数据获取 | TanStack Query（Admin）/ 原生 fetch（Board） |
| 邮件 | Resend |
| 文件存储 | 本地 / S3 兼容 / 七牛云 |
| 测试 | Vitest + Supertest |
| 包管理 | pnpm workspace (monorepo) |

## 项目结构

```
nexus-feedback/
├── packages/
│   ├── server/        # API 服务 (Express + Prisma, port 3000)
│   ├── admin/         # 管理后台 (React, port 8080)
│   ├── board/         # 公开反馈看板 (React, port 8082)
│   ├── widget/        # 可嵌入反馈 Widget (IIFE/ESM)
│   └── submit-page/   # 公开反馈提交页 (React, port 8081)
└── docs/              # 设计文档
```

## 快速开始

### 环境要求

- Node.js >= 18
- pnpm >= 9
- PostgreSQL >= 14

### 安装和启动

```bash
pnpm install

# 配置环境变量
cp packages/server/.env.example packages/server/.env
# 编辑 .env 填入数据库连接和其他配置

# 初始化数据库
cd packages/server
npx prisma db push
npx prisma generate
npx tsx prisma/seed.ts
cd ../..

# 启动所有服务
pnpm dev
```

### 单独启动

```bash
pnpm dev:server   # API 服务        → http://localhost:3000
pnpm dev:admin    # 管理后台        → http://localhost:8080
pnpm dev:board    # 公开看板        → http://localhost:8082/{项目slug}
pnpm dev:submit   # 公开提交页      → http://localhost:8081/?key={API_KEY}
```

### 默认登录凭据

| 项目 | 值 |
|---|---|
| 组织 slug | `demo` |
| 管理员邮箱 | `admin@nexus.dev` |
| 密码 | `admin123` |
| 项目 slug | `demo-project` |
| 项目 API Key | `nf_demo_project_key_789` |
| 公开看板地址 | `http://localhost:8082/demo-project` |
| 提交页地址 | `http://localhost:8081/?key=nf_demo_project_key_789` |

## 开发者接入指南

### 接入方式一：Widget 嵌入（推荐）

在你的网站中嵌入反馈按钮，用户点击后弹出反馈表单。

```html
<script src="https://your-domain.com/nexus-feedback-widget.iife.js"></script>
<script>
  NexusFeedbackWidget.mount(document.createElement('div'), {
    apiKey: 'your-project-api-key',
    apiUrl: 'https://your-domain.com/api/v1',
  });
</script>
```

### 接入方式二：公开提交页

直接链接到独立的反馈提交页面：

```
https://your-domain.com/submit/?key=your-project-api-key
```

### 接入方式三：API 直接调用

#### 提交反馈

```bash
curl -X POST https://your-domain.com/api/v1/feedback \
  -H "Content-Type: application/json" \
  -H "X-API-Key: your-project-api-key" \
  -d '{
    "title": "Bug 报告",
    "content": "详细描述问题",
    "category": "bug",
    "priority": "high",
    "contact": "user@example.com"
  }'
```

#### 请求参数

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `title` | string | 是 | 反馈标题 |
| `content` | string | 是 | 详细描述 |
| `category` | string | 是 | `bug` / `feature` / `performance` / `ui` / `other` |
| `priority` | string | 否 | `low` / `medium`(默认) / `high` / `critical` |
| `contact` | string | 否 | 联系方式 |
| `source` | string | 否 | 来源标识（默认 `api`） |
| `attachment_ids` | string[] | 否 | 附件 ID 数组 |

#### 上传附件

```bash
curl -X POST https://your-domain.com/api/v1/upload \
  -H "X-API-Key: your-project-api-key" \
  -F "file=@screenshot.png"
```

#### 用户投票

```bash
curl -X POST https://your-domain.com/api/v1/public/{slug}/feedback/{id}/vote \
  -H "Content-Type: application/json" \
  -d '{ "email": "voter@example.com" }'
```

### 接入方式四：公开看板

```
https://your-domain.com/{project-slug}
```

## 环境变量

| 变量 | 必填 | 说明 |
|---|---|---|
| `DATABASE_URL` | 是 | PostgreSQL 连接串 |
| `JWT_SECRET` | 是 | JWT 签名密钥（建议 32 位以上） |
| `PORT` | 否 | API 端口（默认 3000） |
| `STORAGE_TYPE` | 否 | `local`(默认) / `s3` / `qiniu` |
| `S3_BUCKET` | 否 | S3 存储桶 |
| `S3_REGION` | 否 | S3 区域 |
| `S3_ENDPOINT` | 否 | S3 端点（MinIO/OSS） |
| `S3_ACCESS_KEY` | 否 | S3 Access Key |
| `S3_SECRET_KEY` | 否 | S3 Secret Key |
| `RESEND_API_KEY` | 否 | Resend 邮件 API Key |
| `FRONTEND_URL` | 否 | 管理后台地址（密码重置链接） |

> 邮件和存储也可在管理后台「系统配置」中设置，无需改环境变量。

## 生产部署（单域名模式）

```nginx
location /api/ {
    proxy_pass http://127.0.0.1:3000;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    client_max_body_size 20m;
}
location /admin/ {
    alias /path/to/packages/admin/dist/;
    try_files $uri $uri/ /admin/index.html;
}
location /submit/ {
    alias /path/to/packages/submit-page/dist/;
    try_files $uri $uri/ /submit/index.html;
}
location / {
    root /path/to/packages/board/dist;
    try_files $uri $uri/ /index.html;
}
```

> 注意：admin 和 submit-page 构建前需设置 `vite.config.ts` 的 `base` 为 `/admin/` 和 `/submit/`。

## Webhook 集成

在管理后台「项目接入」→ 项目 → Webhooks 中配置。

| 事件 | 触发时机 |
|---|---|
| `feedback.created` | 新反馈提交 |
| `feedback.status_changed` | 状态变更 |

请求头包含 `X-Webhook-Signature`（HMAC-SHA256）用于验证来源。

## 开发命令

```bash
pnpm lint        # ESLint 检查
pnpm typecheck   # TypeScript 类型检查
pnpm test        # 运行测试（24 用例）
pnpm build       # 构建所有包
```

## License

MIT
