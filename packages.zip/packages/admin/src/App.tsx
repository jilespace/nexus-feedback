import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { Layout } from '@/components/Layout';
import { Login } from '@/pages/Login';
import { Dashboard } from '@/pages/Dashboard';
import { FeedbackList } from '@/pages/FeedbackList';
import { FeedbackDetail } from '@/pages/FeedbackDetail';
import { Applications } from '@/pages/Applications';
import { ProjectSettings } from '@/pages/ProjectSettings';
import { Members } from '@/pages/Members';
import { Tags } from '@/pages/Tags';
import { Changelog } from '@/pages/Changelog';
import { OrgSettings } from '@/pages/OrgSettings';
import { Webhooks } from '@/pages/Webhooks';
import { StatusSettings } from '@/pages/StatusSettings';
import { WidgetConfig } from '@/pages/WidgetConfig';
import { SystemConfig } from '@/pages/SystemConfig';
import { Notifications } from '@/pages/Notifications';

export function App() {
  const { isAuthenticated } = useAuth();

  if (!isAuthenticated) {
    return <Login />;
  }

  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/feedback" element={<FeedbackList />} />
        <Route path="/feedback/:id" element={<FeedbackDetail />} />
        <Route path="/changelog" element={<Changelog />} />
        <Route path="/applications" element={<Applications />} />
        <Route path="/projects/:projectId/settings" element={<ProjectSettings />} />
        <Route path="/projects/:projectId/widget" element={<WidgetConfig />} />
        <Route path="/members" element={<Members />} />
        <Route path="/tags" element={<Tags />} />
        <Route path="/projects/:projectId/webhooks" element={<Webhooks />} />
        <Route path="/projects/:projectId/statuses" element={<StatusSettings />} />
        <Route path="/projects/:projectId/notifications" element={<Notifications />} />
        <Route path="/settings" element={<OrgSettings />} />
        <Route path="/system-config" element={<SystemConfig />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Layout>
  );
}
