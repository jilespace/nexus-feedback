﻿import { NavLink } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useAuth } from '@/hooks/useAuth';
import { useTheme } from '@/hooks/useTheme';
import { useKeyboardShortcuts } from '@/hooks/useKeyboardShortcuts';
import { ShortcutHelp } from '@/components/ShortcutHelp';
import { clsx } from 'clsx';
import type { ReactNode } from 'react';

const navItems = [
  { to: '/', labelKey: 'nav.dashboard', icon: DashboardIcon },
  { to: '/feedback', labelKey: 'nav.feedback', icon: FeedbackIcon },
  { to: '/changelog', labelKey: 'nav.changelog', icon: ChangelogNavIcon },
  { to: '/applications', labelKey: 'nav.applications', icon: AppsIcon },
  { to: '/members', labelKey: 'nav.members', icon: MembersIcon },
  { to: '/tags', labelKey: 'nav.tags', icon: TagsIcon },
  { to: '/system-config', labelKey: 'nav.systemConfig', icon: SystemConfigIcon },
  { to: '/settings', labelKey: 'nav.settings', icon: SettingsIcon },
];

export function Layout({ children }: { children: ReactNode }) {
  const { t, i18n } = useTranslation();
  const { logout, member, organization } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const { showHelp, setShowHelp } = useKeyboardShortcuts();

  const toggleLang = () => {
    const next = i18n.language === 'zh' ? 'en' : 'zh';
    i18n.changeLanguage(next);
    localStorage.setItem('lang', next);
  };

  const displayName = member?.display_name ?? '管理员';
  const roleBadge = member?.role ?? 'member';
  const orgName = organization?.name ?? 'Nexus';

  return (
    <div className="flex h-screen overflow-hidden bg-surface-1 dark:bg-gray-900">
      <aside className="flex w-60 flex-col border-r border-surface-3 bg-surface-0 dark:border-gray-700 dark:bg-gray-800">
        <div className="flex h-14 items-center gap-2.5 px-5">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-brand-600">
            <span className="text-xs font-bold text-white">{orgName[0]}</span>
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-bold text-gray-900 dark:text-gray-100">{orgName}</span>
            <span className="text-[10px] font-medium leading-none text-gray-400 dark:text-gray-500">Feedback</span>
          </div>
        </div>
        <nav className="flex-1 space-y-0.5 px-3 py-4">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/'}
              className={({ isActive }) =>
                clsx(
                  'group relative flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all',
                  isActive
                    ? 'bg-brand-50 text-brand-700 dark:bg-brand-900/30 dark:text-brand-300'
                    : 'text-gray-600 hover:bg-surface-2 hover:text-gray-900 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-gray-100',
                )
              }
            >
              {({ isActive }) => (
                <>
                  {isActive && (
                    <span className="absolute left-0 top-1/2 h-5 w-[3px] -translate-y-1/2 rounded-r-full bg-brand-600" />
                  )}
                  <item.icon active={isActive} />
                  {t(item.labelKey)}
                </>
              )}
            </NavLink>
          ))}
        </nav>
        <div className="border-t border-surface-3 p-3 dark:border-gray-700">
          <div className="flex items-center gap-3 rounded-lg px-3 py-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-brand-100 text-xs font-semibold text-brand-700 dark:bg-brand-900/40 dark:text-brand-300">
              {displayName[0]}
            </div>
            <div className="flex-1 min-w-0">
              <p className="truncate text-sm font-medium text-gray-900 dark:text-gray-100">{displayName}</p>
              <p className="truncate text-xs text-gray-400 dark:text-gray-500">{roleBadge}</p>
            </div>
            <button
              onClick={toggleLang}
              className="flex h-8 w-8 items-center justify-center rounded-lg text-xs font-bold text-gray-400 transition-colors hover:bg-surface-2 hover:text-gray-600 dark:hover:bg-gray-700 dark:hover:text-gray-200"
              title={i18n.language === 'zh' ? 'English' : '中文'}
            >
              {i18n.language === 'zh' ? 'EN' : '中'}
            </button>
            <button
              onClick={toggleTheme}
              className="flex h-8 w-8 items-center justify-center rounded-lg text-gray-400 transition-colors hover:bg-surface-2 hover:text-gray-600 dark:hover:bg-gray-700 dark:hover:text-gray-200"
              title={theme === 'dark' ? t('common.lightMode') : t('common.darkMode')}
            >
              {theme === 'dark' ? <SunIcon /> : <MoonIcon />}
            </button>
          </div>
          <button
            onClick={logout}
            className="mt-1 flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-sm text-gray-500 transition-colors hover:bg-surface-2 hover:text-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-gray-200 focus:outline-none focus:ring-2 focus:ring-brand-100"
          >
            <LogoutIcon />
            {t('common.logout')}
          </button>
        </div>
      </aside>
      <main className="flex-1 overflow-y-auto bg-surface-1 p-6 dark:bg-gray-900">
        {children}
      </main>
      {showHelp && <ShortcutHelp onClose={() => setShowHelp(false)} />}
    </div>
  );
}

function DashboardIcon({ active }: { active: boolean }) {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" className={clsx(active ? 'text-brand-600' : 'text-gray-400 group-hover:text-gray-600')}>
      <rect x="2" y="2" width="6" height="6" rx="1.5" fill="currentColor" opacity="0.9" />
      <rect x="10" y="2" width="6" height="6" rx="1.5" fill="currentColor" opacity="0.5" />
      <rect x="2" y="10" width="6" height="6" rx="1.5" fill="currentColor" opacity="0.5" />
      <rect x="10" y="10" width="6" height="6" rx="1.5" fill="currentColor" opacity="0.3" />
    </svg>
  );
}

function FeedbackIcon({ active }: { active: boolean }) {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" className={clsx(active ? 'text-brand-600' : 'text-gray-400 group-hover:text-gray-600')}>
      <path d="M3 4.5C3 3.67 3.67 3 4.5 3h9c.83 0 1.5.67 1.5 1.5v7c0 .83-.67 1.5-1.5 1.5H7l-3 2.5V13H4.5C3.67 13 3 12.33 3 11.5v-7z" fill="currentColor" opacity="0.7" />
      <circle cx="6.5" cy="8" r="0.75" fill="white" />
      <circle cx="9" cy="8" r="0.75" fill="white" />
      <circle cx="11.5" cy="8" r="0.75" fill="white" />
    </svg>
  );
}

function AppsIcon({ active }: { active: boolean }) {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" className={clsx(active ? 'text-brand-600' : 'text-gray-400 group-hover:text-gray-600')}>
      <rect x="3" y="3" width="5" height="5" rx="1" fill="currentColor" opacity="0.8" />
      <rect x="10" y="3" width="5" height="5" rx="1" fill="currentColor" opacity="0.5" />
      <rect x="3" y="10" width="5" height="5" rx="1" fill="currentColor" opacity="0.5" />
      <circle cx="12.5" cy="12.5" r="2" fill="currentColor" opacity="0.7" />
    </svg>
  );
}

function MembersIcon({ active }: { active: boolean }) {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" className={clsx(active ? 'text-brand-600' : 'text-gray-400 group-hover:text-gray-600')}>
      <circle cx="7" cy="6" r="2.5" fill="currentColor" opacity="0.8" />
      <path d="M3 14c0-2.2 1.8-4 4-4s4 1.8 4 4" fill="currentColor" opacity="0.5" />
      <circle cx="12" cy="7" r="1.5" fill="currentColor" opacity="0.5" />
      <path d="M12 10c1.7 0 3 1.3 3 3" stroke="currentColor" strokeWidth="1.2" opacity="0.4" fill="none" />
    </svg>
  );
}

function TagsIcon({ active }: { active: boolean }) {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" className={clsx(active ? 'text-brand-600' : 'text-gray-400 group-hover:text-gray-600')}>
      <path d="M3 4a1 1 0 011-1h4.586a1 1 0 01.707.293l5.414 5.414a1 1 0 010 1.414l-4.586 4.586a1 1 0 01-1.414 0L3.293 9.293A1 1 0 013 8.586V4z" fill="currentColor" opacity="0.7" />
      <circle cx="6" cy="6" r="1" fill="white" />
    </svg>
  );
}

function ChangelogNavIcon({ active }: { active: boolean }) {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" className={clsx(active ? 'text-brand-600' : 'text-gray-400 group-hover:text-gray-600')}>
      <rect x="3" y="2" width="12" height="14" rx="2" fill="currentColor" opacity="0.7" />
      <path d="M6 6h6M6 9h5M6 12h3" stroke="white" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}

function LogoutIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" className="text-gray-400">
      <path d="M6 2H4a2 2 0 00-2 2v8a2 2 0 002 2h2M10.5 11.5L14 8l-3.5-3.5M14 8H6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function SettingsIcon({ active }: { active: boolean }) {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" className={clsx(active ? 'text-brand-600' : 'text-gray-400 group-hover:text-gray-600')}>
      <path d="M9 11.5a2.5 2.5 0 100-5 2.5 2.5 0 000 5z" fill="currentColor" opacity="0.7" />
      <path d="M14.7 7.1l-.9-.5a5.5 5.5 0 000-1.2l.9-.5a.5.5 0 00.2-.6l-.8-1.4a.5.5 0 00-.6-.2l-.9.5a5.5 5.5 0 00-1-.6V1.5a.5.5 0 00-.5-.5h-1.6a.5.5 0 00-.5.5v1a5.5 5.5 0 00-1 .6l-.9-.5a.5.5 0 00-.6.2l-.8 1.4a.5.5 0 00.2.6l.9.5a5.5 5.5 0 000 1.2l-.9.5a.5.5 0 00-.2.6l.8 1.4a.5.5 0 00.6.2l.9-.5a5.5 5.5 0 001 .6v1a.5.5 0 00.5.5h1.6a.5.5 0 00.5-.5v-1a5.5 5.5 0 001-.6l.9.5a.5.5 0 00.6-.2l.8-1.4a.5.5 0 00-.2-.6z" stroke="currentColor" strokeWidth="1" fill="none" opacity="0.5" />
    </svg>
  );
}

function SystemConfigIcon({ active }: { active: boolean }) {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" className={clsx(active ? 'text-brand-600' : 'text-gray-400 group-hover:text-gray-600')}>
      <rect x="3" y="4" width="12" height="10" rx="2" fill="currentColor" opacity="0.3" />
      <path d="M6 7h6M6 9.5h4M6 12h5" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" opacity="0.8" />
    </svg>
  );
}

function SunIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <circle cx="8" cy="8" r="3" />
      <path d="M8 1.5v1M8 13.5v1M1.5 8h1M13.5 8h1M3.4 3.4l.7.7M11.9 11.9l.7.7M3.4 12.6l.7-.7M11.9 4.1l.7-.7" />
    </svg>
  );
}

function MoonIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M13.5 8.5a5.5 5.5 0 01-7.5-5c0-.5 0-1 .1-1.5A5.5 5.5 0 108 14a5.5 5.5 0 005.5-5.5z" />
    </svg>
  );
}