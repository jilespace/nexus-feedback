﻿import { useQuery } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { apiRequest } from '@/api/client';
import { Skeleton } from '@/components/Skeleton';
import { StatusBadge } from '@/components/StatusBadge';
import { formatRelativeTime } from '@/utils/formatRelativeTime';
import type { FeedbackItem, PaginatedResponse, Stats } from '@/types';

type DashboardStats = Stats;

const CATEGORY_LABELS: Record<string, string> = {
  bug: 'Bug', feature: '功能', performance: '性能', ui: 'UI', other: '其他',
};

const CATEGORY_COLORS: Record<string, string> = {
  bug: 'bg-red-500', feature: 'bg-brand-500', performance: 'bg-amber-500', ui: 'bg-purple-500', other: 'bg-gray-400',
};

export function Dashboard() {
  const navigate = useNavigate();
  const { t } = useTranslation();

  const STAT_CARDS_RUNTIME = [
    { key: 'total', label: t('dashboard.total_feedback'), icon: TotalIcon, accent: 'bg-gray-50 text-gray-700 dark:bg-gray-700 dark:text-gray-200' },
    { key: 'open', label: t('dashboard.open_count'), icon: OpenIcon, accent: 'bg-amber-50 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300' },
    { key: 'in_progress', label: t('feedback.status_in_progress'), icon: ProgressIcon, accent: 'bg-blue-50 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300' },
    { key: 'resolved', label: t('dashboard.resolved_count'), icon: ResolvedIcon, accent: 'bg-green-50 text-green-700 dark:bg-green-900/30 dark:text-green-300' },
    { key: 'closed', label: t('feedback.status_closed'), icon: ClosedIcon, accent: 'bg-gray-100 text-gray-500 dark:bg-gray-700 dark:text-gray-400' },
  ] as const;

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ['stats'],
    queryFn: () => apiRequest<DashboardStats>('/admin/stats'),
  });

  const { data: recent } = useQuery({
    queryKey: ['feedback', 1, {}],
    queryFn: () => apiRequest<PaginatedResponse<FeedbackItem>>('/admin/feedback?page=1&page_size=5'),
  });

  if (statsLoading) return <DashboardSkeleton />;
  if (!stats) return <div className="text-sm text-red-600">加载失败</div>;

  const maxCategory = Math.max(...Object.values(stats.by_category), 1);

  return (
    <div className="space-y-6">
      <h1 className="text-lg font-semibold text-gray-900 dark:text-gray-100">{t('dashboard.title')}</h1>
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
        {STAT_CARDS_RUNTIME.map((card) => (
          <div
            key={card.key}
            className={`group relative overflow-hidden rounded-xl border border-surface-3 p-4 transition-shadow hover:shadow-md ${card.accent}`}
          >
            <div className="flex items-start justify-between">
              <div>
                <p className="text-2xl font-bold">{stats[card.key]}</p>
                <p className="mt-1 text-xs font-medium opacity-70">{card.label}</p>
              </div>
              <card.icon />
            </div>
          </div>
        ))}
      </div>
      {stats.by_week?.length > 0 && <WeeklyTrendChart data={stats.by_week} />}
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 rounded-xl border border-surface-3 bg-surface-0 p-5 dark:border-gray-700 dark:bg-gray-800">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-sm font-semibold text-gray-900 dark:text-gray-100">最近反馈</h2>
            <button onClick={() => navigate('/feedback')} className="text-xs font-medium text-brand-600 hover:text-brand-700 dark:text-brand-400 dark:hover:text-brand-300">
              查看全部 →
            </button>
          </div>
          {recent?.items.length ? (
            <div className="space-y-2">
              {recent.items.map((item) => (
                <div
                  key={item.id}
                  onClick={() => navigate(`/feedback/${item.id}`)}
                  className="flex cursor-pointer items-center gap-3 rounded-lg px-3 py-2.5 transition-colors hover:bg-surface-1 dark:hover:bg-gray-700"
                >
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-gray-900 dark:text-gray-100">{item.title}</p>
                    <p className="mt-0.5 text-xs text-gray-500 dark:text-gray-400">{formatRelativeTime(item.created_at)}</p>
                  </div>
                  <StatusBadge status={item.status} />
                </div>
              ))}
            </div>
          ) : (
            <p className="py-8 text-center text-sm text-gray-400">暂无反馈</p>
          )}
        </div>
        <div className="rounded-xl border border-surface-3 bg-surface-0 p-5 dark:border-gray-700 dark:bg-gray-800">
          <h2 className="mb-4 text-sm font-semibold text-gray-900 dark:text-gray-100">分类分布</h2>
          <div className="space-y-3">
            {Object.entries(stats.by_category).map(([cat, count]) => (
              <div key={cat} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-medium text-gray-700 dark:text-gray-300">{CATEGORY_LABELS[cat] ?? cat}</span>
                  <span className="text-gray-500 dark:text-gray-400">{count}</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-surface-2">
                  <div
                    className={`h-full rounded-full transition-all ${CATEGORY_COLORS[cat] ?? 'bg-gray-400'}`}
                    style={{ width: `${(count / maxCategory) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function WeeklyTrendChart({ data }: { data: { week: string; count: number }[] }) {
  const items = data.slice(-8);
  const maxCount = Math.max(...items.map((d) => d.count), 1);
  const chartW = 100;
  const chartH = 40;
  const padX = 0;
  const padY = 4;
  const innerW = chartW - padX * 2;
  const innerH = chartH - padY * 2;

  const points = items.map((d, i) => {
    const x = padX + (items.length > 1 ? (i / (items.length - 1)) * innerW : innerW / 2);
    const y = padY + innerH - (d.count / maxCount) * innerH;
    return `${x},${y}`;
  });

  const areaPath = items.length > 1
    ? `M${points[0]} ${points.slice(1).map((p) => `L${p}`).join(' ')} L${padX + innerW},${chartH} L${padX},${chartH} Z`
    : '';

  return (
    <div className="rounded-xl border border-surface-3 bg-surface-0 p-5 dark:border-gray-700 dark:bg-gray-800">
      <h2 className="mb-4 text-sm font-semibold text-gray-900 dark:text-gray-100">周趋势</h2>
      <svg viewBox={`0 0 ${chartW} ${chartH + 12}`} className="w-full h-32" preserveAspectRatio="none">
        <defs>
          <linearGradient id="trendFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="var(--color-brand-500, #6366f1)" stopOpacity="0.2" />
            <stop offset="100%" stopColor="var(--color-brand-500, #6366f1)" stopOpacity="0" />
          </linearGradient>
        </defs>
        {areaPath && <path d={areaPath} fill="url(#trendFill)" />}
        {items.length > 1 && (
          <polyline
            points={points.join(' ')}
            fill="none"
            stroke="var(--color-brand-500, #6366f1)"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            vectorEffect="non-scaling-stroke"
          />
        )}
        {items.map((d, i) => {
          const x = padX + (items.length > 1 ? (i / (items.length - 1)) * innerW : innerW / 2);
          const y = padY + innerH - (d.count / maxCount) * innerH;
          return (
            <circle key={i} cx={x} cy={y} r="1.5" fill="var(--color-brand-600, #4f46e5)" />
          );
        })}
        {items.map((d, i) => {
          const x = padX + (items.length > 1 ? (i / (items.length - 1)) * innerW : innerW / 2);
          return (
            <text key={i} x={x} y={chartH + 10} textAnchor="middle" fontSize="3" fill="#9ca3af">
              {d.week.replace(/^\d{4}-W/, 'W')}
            </text>
          );
        })}
      </svg>
    </div>
  );
}

function DashboardSkeleton() {
  return (
    <div className="space-y-6">
      <Skeleton className="h-6 w-16" />
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
        {Array.from({ length: 5 }).map((_, i) => (
          <Skeleton key={i} className="h-24 rounded-xl" variant="rectangular" />
        ))}
      </div>
    </div>
  );
}

function TotalIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor" className="opacity-40">
      <path d="M4 4h5v5H4V4zm7 0h5v5h-5V4zm-7 7h5v5H4v-5zm7 0h5v5h-5v-5z" />
    </svg>
  );
}

function OpenIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor" className="opacity-40">
      <circle cx="10" cy="10" r="7" fill="none" stroke="currentColor" strokeWidth="2" />
      <circle cx="10" cy="10" r="3" />
    </svg>
  );
}

function ProgressIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor" className="opacity-40">
      <path d="M10 3a7 7 0 100 14 7 7 0 000-14zm0 2v5l3.5 2" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

function ResolvedIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor" className="opacity-40">
      <path d="M10 3a7 7 0 100 14 7 7 0 000-14z" fill="none" stroke="currentColor" strokeWidth="2" />
      <path d="M7 10l2 2 4-4" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function ClosedIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor" className="opacity-40">
      <path d="M10 3a7 7 0 100 14 7 7 0 000-14z" fill="none" stroke="currentColor" strokeWidth="2" />
      <path d="M13 7L7 13M7 7l6 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}
