import { prisma } from '../db/client.js';
import { NotFoundError, ValidationError, ConflictError } from '../utils/errors.js';

export async function mergeFeedback(sourceId: string, targetId: string) {
  if (sourceId === targetId) {
    throw new ValidationError('不能将反馈合并到自身');
  }

  const [source, target] = await Promise.all([
    prisma.feedback.findUnique({ where: { id: sourceId } }),
    prisma.feedback.findUnique({ where: { id: targetId } }),
  ]);

  if (!source) throw new NotFoundError('源反馈不存在');
  if (!target) throw new NotFoundError('目标反馈不存在');
  if (source.merged_into_id) {
    throw new ConflictError('该反馈已被合并');
  }

  // Find duplicate votes (same email exists on both)
  const sourceVotes = await prisma.vote.findMany({
    where: { feedback_id: sourceId },
  });
  const targetVotes = await prisma.vote.findMany({
    where: { feedback_id: targetId },
  });

  const targetEmails = new Set(targetVotes.map((v) => v.email));
  const duplicateVoteIds: string[] = [];
  const transferVoteIds: string[] = [];

  for (const vote of sourceVotes) {
    if (targetEmails.has(vote.email)) {
      duplicateVoteIds.push(vote.id);
    } else {
      transferVoteIds.push(vote.id);
    }
  }

  const newVoteCount = target.vote_count + transferVoteIds.length;

  await prisma.$transaction([
    // Delete duplicate votes
    ...(duplicateVoteIds.length > 0
      ? [prisma.vote.deleteMany({ where: { id: { in: duplicateVoteIds } } })]
      : []),
    // Transfer non-duplicate votes
    ...(transferVoteIds.length > 0
      ? [prisma.vote.updateMany({
          where: { id: { in: transferVoteIds } },
          data: { feedback_id: targetId },
        })]
      : []),
    // Update target vote_count
    prisma.feedback.update({
      where: { id: targetId },
      data: { vote_count: newVoteCount },
    }),
    // Mark source as merged and closed
    prisma.feedback.update({
      where: { id: sourceId },
      data: { merged_into_id: targetId, status: 'closed' },
    }),
  ]);

  const updated = await prisma.feedback.findUnique({ where: { id: targetId } });
  return updated;
}
