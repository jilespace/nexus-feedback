import { prisma } from '../db/client.js';
import { sendEmail, sendBatchEmails } from './email.js';

export async function notifyStatusChange(feedbackId: string, newStatus: string): Promise<void> {
  const feedback = await prisma.feedback.findUnique({
    where: { id: feedbackId },
    include: { votes: { select: { email: true } } },
  });
  if (!feedback) return;

  const emails = new Set<string>();
  if (feedback.contact) emails.add(feedback.contact);
  for (const vote of feedback.votes) {
    emails.add(vote.email);
  }
  if (emails.size === 0) return;

  // Check preferences
  const prefs = await prisma.notificationPreference.findMany({
    where: { email: { in: [...emails] }, project_id: feedback.project_id ?? '' },
  });
  const disabledEmails = new Set(
    prefs.filter((p) => !p.status_updates).map((p) => p.email),
  );

  const recipients = [...emails].filter((e) => !disabledEmails.has(e));
  if (recipients.length === 0) return;

  const subject = `Feedback status updated: ${feedback.title}`;
  const html = buildStatusChangeEmail(feedback.title, newStatus, feedbackId);
  await sendBatchEmails(recipients, subject, html);
}

export async function notifyNewFeedback(feedbackId: string, orgId: string): Promise<void> {
  const feedback = await prisma.feedback.findUnique({ where: { id: feedbackId } });
  if (!feedback) return;

  const members = await prisma.member.findMany({
    where: { org_id: orgId, role: { in: ['owner', 'admin'] } },
    select: { email: true },
  });
  if (members.length === 0) return;

  const subject = `New feedback: ${feedback.title}`;
  const html = buildNewFeedbackEmail(feedback.title, feedback.category, feedbackId);
  await sendBatchEmails(members.map((m) => m.email), subject, html);
}

export async function notifyReply(feedbackId: string, replyContent: string): Promise<void> {
  const feedback = await prisma.feedback.findUnique({ where: { id: feedbackId } });
  if (!feedback || !feedback.contact) return;

  const subject = `New reply on: ${feedback.title}`;
  const html = buildReplyEmail(feedback.title, replyContent, feedbackId);
  await sendEmail(feedback.contact, subject, html);
}

function buildStatusChangeEmail(title: string, newStatus: string, feedbackId: string): string {
  return `<div style="font-family:sans-serif;max-width:600px;margin:0 auto">
<h2>Feedback Status Updated</h2>
<p><strong>${title}</strong></p>
<p>New status: <strong>${newStatus}</strong></p>
<p><a href="https://app.nexus-feedback.dev/feedback/${feedbackId}">View feedback</a></p>
<hr/>
<p style="font-size:12px;color:#666"><a href="https://app.nexus-feedback.dev/unsubscribe">Unsubscribe</a></p>
</div>`;
}

function buildNewFeedbackEmail(title: string, category: string, feedbackId: string): string {
  return `<div style="font-family:sans-serif;max-width:600px;margin:0 auto">
<h2>New Feedback Submitted</h2>
<p><strong>${title}</strong></p>
<p>Category: ${category}</p>
<p><a href="https://app.nexus-feedback.dev/feedback/${feedbackId}">View feedback</a></p>
</div>`;
}

function buildReplyEmail(title: string, replyContent: string, feedbackId: string): string {
  return `<div style="font-family:sans-serif;max-width:600px;margin:0 auto">
<h2>New Reply</h2>
<p>A reply was posted on: <strong>${title}</strong></p>
<blockquote style="border-left:3px solid #ccc;padding-left:12px;color:#555">${replyContent}</blockquote>
<p><a href="https://app.nexus-feedback.dev/feedback/${feedbackId}">View feedback</a></p>
<hr/>
<p style="font-size:12px;color:#666"><a href="https://app.nexus-feedback.dev/unsubscribe">Unsubscribe</a></p>
</div>`;
}
