import { describe, it, expect } from 'vitest';
import { validateCreateFeedback } from '../feedback.js';

describe('FeedbackService', () => {
  describe('validateCreateFeedback', () => {
    it('should validate valid input', () => {
      const input = {
        title: 'Test feedback',
        content: 'This is a test',
        category: 'bug',
        priority: 'medium',
      };
      const result = validateCreateFeedback(input);
      expect(result.title).toBe('Test feedback');
      expect(result.category).toBe('bug');
      expect(result.priority).toBe('medium');
    });

    it('should throw ValidationError when title is empty', () => {
      const input = {
        title: '',
        content: 'Content',
        category: 'bug',
      };
      expect(() => validateCreateFeedback(input)).toThrow();
    });

    it('should throw ValidationError for unsupported category', () => {
      const input = {
        title: 'Test',
        content: 'Content',
        category: 'invalid_category',
      };
      expect(() => validateCreateFeedback(input)).toThrow();
    });

    it('should default priority to medium', () => {
      const input = {
        title: 'Test',
        content: 'Content',
        category: 'feature',
      };
      const result = validateCreateFeedback(input);
      expect(result.priority).toBe('medium');
    });

    it('should accept optional fields', () => {
      const input = {
        title: 'Test',
        content: 'Content',
        category: 'ui',
        contact: 'user@example.com',
        app_version: '1.0.0',
        metadata: { page_url: 'https://example.com' },
        attachment_ids: ['id-1', 'id-2'],
      };
      const result = validateCreateFeedback(input);
      expect(result.contact).toBe('user@example.com');
      expect(result.attachment_ids).toHaveLength(2);
    });
  });
});
